# Program 1 
'''
import pygame
import math

# Anything under will be imported in pygame
pygame.init()
# to create the screen and set a size to it(Need double brackets on the size)
screen = pygame.display.set_mode((800,600))

#Title and icon
pygame.display.set_caption("Player 1 vs Player 2")
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)

def text(msg,colour,box,x,y,w,h):
    font = pygame.font.Font('freesansbold.ttf', 32)
    text = font.render(msg, True, colour, box)
    textRect = text.get_rect()
    textRect.center = (x + (w // 2),y + (h // 2))
    screen.blit(text, textRect)


def button(x,y,w,h,msg,boxAC,boxNAC,txtcolourAC,txtcolourNAC,action = None,border = None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y: 
        pygame.draw.rect(screen, boxAC,(x,y,w,h))
        text(msg,txtcolourAC,boxAC,x,y,w,h)
        if click[0] == 1 and action != None:
            if action == "start":
                game_loop()
            elif action == "quit":
                pygame.quit()
                exit()
            elif action == "try again":
                game_loop()
    else:
        pygame.draw.rect(screen, boxNAC,(x,y,w,h))
        text(msg,txtcolourNAC,boxNAC,x,y,w,h)
    if border == None:
        pygame.draw.rect(screen,(0,0,0),(x,y,10,h))
        pygame.draw.rect(screen,(0,0,0),(x,y,w,10))
        pygame.draw.rect(screen,(0,0,0),(x + w - 10,y,10,h))
        pygame.draw.rect(screen,(0,0,0),(x,y + h - 10,w,10))
blue = (0,0,255)
green = (0,255,0)
red = (255,0,0)
orange =(255,200,0)
score1 = 0
score2 = 0
def game_loop():
    # Player 1 
    player_img = pygame.image.load("rocket_0.gif")
    playerw = 0
    playerh = 550

    def player(x,y):
        screen.blit(player_img,(x,y))

    # Player 2
    player_img2 = pygame.image.load("rocket_2.gif")
    playerw2 = 750
    playerh2 = 0

    def player2(x,y):
        screen.blit(player_img2,(x,y))

    #Bullet 1
    bullet_img = pygame.image.load("bullet.png")
    bulletw = -100
    bulleth = -100

    def bullet(x,y):
        screen.blit(bullet_img,(x,y))

    #Bullet 2
    bullet_img2 = pygame.image.load("bullet2.png")
    bulletw2 = 600
    bulleth2 = 600

    def bullet2(x,y):
        screen.blit(bullet_img2,(x,y))

    # win image
    win_img = pygame.image.load("youwin.png")


    def win(x,y):
        screen.blit(win_img,(x,y))

    # Detects if the bullet makes contact
    def collided1(playerw,playerh,bulletw2,bulleth2,hit = False):
        global score1
        global score2
        distance = math.sqrt((math.pow((playerw + 32) - (bulletw2 + 16),2)) + (math.pow((playerh + 32) - (bulleth2 + 16),2)))    
        if distance < 32:
            score2 = score2 + 1
            while True:
                screen.fill((255,255,255))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                win(75,300)
                player2(playerw2,playerh2)
                button(100,50,200,100,"Try Again",green,blue,blue,green,action = "try again")
                button(500,50,200,100,"Quit",orange,red,red,orange,action = "quit")
                pygame.display.update()
            else:
                pass

    def collided2(playerw2,playerh2,bulletw,bulleth,hit2 = False):
        global score1
        global score2
        distance2 = math.sqrt((math.pow((playerw2 + 32) - (bulletw + 16),2)) + (math.pow((playerh2 - 32) - (bulleth - 16),2)))
        if distance2 < 25:
            score1 = score1 + 1
            while+ True:
                screen.fill((255,255,255))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                win(75,0)
                button(100,385,200,100,"Try Again",green,blue,blue,green,action = "try again")
                button(500,385,200,100,"Quit",orange,red,red,orange,action = "quit")
                player(playerw,playerh)
                pygame.display.update()
        else:
            pass
    while True:
        screen.fill((255,255,255))
        pygame.draw.rect(screen, blue,(0,300,800,10))
        bullet(bulletw,bulleth)
        bullet2(bulletw2,bulleth2)
# RGB - Red, Green, Blue
        for event in pygame.event.get():
# Checks if anything has happen in the game ex(Pressed the close button)
            if event.type == pygame.QUIT:
# This specifies the event we are looking
# for in pygame in this case we are checking if the quit button has beeen pressed
                pygame.quit()
# pygame.quit() closes the system
                exit()
# exit() actually closes the program
            if bulleth <= 0:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    bulletw = playerw + 18
                    bulleth = playerh - 33
            if event.type == pygame.KEYDOWN:
# KEYDOWN checks if any key is presssed
                if event.key == pygame.K_LEFT:
                    if playerw > 0:
                        playerw = playerw - 20
                    else:
                        pass
                if event.key == pygame.K_RIGHT:
                    if playerw < 750:
                        playerw = playerw + 20
                    else:
                        pass
                if event.key == pygame.K_UP:
                    if playerh > 320:
                        playerh = playerh - 20
                    else:
                        pass
                if event.key == pygame.K_DOWN:
                    if playerh < 550:
                        playerh = playerh  + 20
                    else:
                        pass
                if event.key == pygame.K_d:
                    if playerw2 < 750:
                        playerw2 = playerw2 + 20
                    else:
                        pass
                if event.key == pygame.K_a:
                    if playerw2 > 0:
                        playerw2 = playerw2 - 20
                    else:
                        pass
                if event.key == pygame.K_w:
                    if playerh2 > 0:
                        playerh2 = playerh2 - 20
                    else:
                        pass
                if event.key == pygame.K_s:
                    if playerh2 < 230:
                        playerh2 = playerh2  + 20
                    else:
                        pass
                if bulleth2 >= 550:
                    if event.key == pygame.K_SPACE:
                        bulletw2 = playerw2 + 15
                        bulleth2 = playerh2 + 45
# if key pressed checek if it is right or left or up or down key
        if True:
            bulleth = bulleth - 2.5
            bulleth2 = bulleth2 + 2.5
        else:
            pass
# To move bullet
        collided1(playerw,playerh,bulletw2,bulleth2)
        collided2(playerw2,playerh2,bulletw,bulleth)
# To recognize the bullet touching the opposing player

        text(f"Score: {score2}",(0,0,0),(255,255,255),0,0,175,30)
        text(f"Score: {score1}",(0,0,0),(255,255,255),0,570,175,30)
        player(playerw,playerh)
        player2(playerw2,playerh2)
        pygame.display.update()
# update to keep the game to be running smooth
starting_img = pygame.image.load("startingrocket.png")

def startingpic(x,y):
    screen.blit(starting_img,(x,y))
while True:
    screen.fill((0,0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    startingpic(100,0)
    button(100,385,200,100,"Start",green,blue,blue,green,action = "start",border = "No")
    button(500,385,200,100,"Quit",orange,red,red,orange,action = "quit",border = "No")
    pygame.display.update()
'''
# Program 2
'''
import pygame
import random
import math

pygame.init()
screen = pygame.display.set_mode((1000,650))

#icon and Title
pygame.display.set_caption("Ballon in Bucket")
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)

score = 0

def game_loop():
    global score
    # Bucket
    bucket_img = pygame.image.load("bucket.png")
    bucketw = 420
    bucketh = 400

    def bucket(x,y):
        screen.blit(bucket_img,(x,y))

    # ballon
    ballon_img = pygame.image.load("ballon.png")
    ballonw = random.randint(0,850)
    ballonh = 0

    # Lose
    lose_img = pygame.image.load("lose.png")

    def lose(x,y):
        screen.blit(lose_img,(x,y))

    def ballon(x,y):
        screen.blit(ballon_img,(x,y))
    def collid(bucketw,bucketh,ballonw,ballonh):
        global score
        distance = math.sqrt((math.pow((bucketw + 128) - (ballonw + 68),2) + (math.pow((bucketh - 128) - (ballonh - 133),2))))
        if distance < 150:
            ballonw = random.randint(0,850)
            ballonh = 0
            score = score + 1
            while True:
                screen.fill((255,255,255))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_LEFT:
                            if bucketw > 0:
                                bucketw = bucketw - 50
                            else:
                                pass
                        if event.key == pygame.K_RIGHT:
                            if bucketw < 720:
                                bucketw = bucketw + 50
                ballon(ballonw,ballonh)
                if ballonh < 900:
                    ballonh = ballonh + 1.4
                elif ballonh >= 0:
                    while True:
                        screen.fill((255,255,255))
                        for event in pygame.event.get():
                            if event.type == pygame.QUIT:
                                pygame.quit
                                exit
                        lose(200,250)
                        score = 0
                        button(25,50,375,200,"Try Again",blue,green,green,blue,size = 50,action = "play")
                        button(600,50,375,200,"Quit",red,orange,orange,red,size = 50,action = "quit")
                        pygame.display.update()
                else:
                    pass
                collid(bucketw,bucketh,ballonw,ballonh)
                bucket(bucketw,bucketh)
                text(f"Score: {score}",(0,0,0),(255,255,255),0,0,150,30,size = 32)
                pygame.display.update()
    while True:
        screen.fill((255,255,255))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if bucketw > 0:
                        bucketw = bucketw - 50
                    else:
                        pass
                if event.key == pygame.K_RIGHT:
                    if bucketw < 720:
                        bucketw = bucketw + 50
        ballon(ballonw,ballonh)
        if ballonh < 900:
            ballonh = ballonh + 1.4
        elif ballonh >= 0:
            while True:
                screen.fill((255,255,255))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit
                        exit
                lose(200,250)
                score = 0
                button(25,50,375,200,"Try Again",blue,green,green,blue,size = 50,action = "play")
                button(600,50,375,200,"Quit",red,orange,orange,red,size = 50,action = "quit")
                pygame.display.update()
        else:
            pass
        collid(bucketw,bucketh,ballonw,ballonh)
        bucket(bucketw,bucketh)
        text(f"Score: {score}",(0,0,0),(255,255,255),0,0,150,30,size = 32)
        pygame.display.update()
blue = (0,0,255)
green = (0,255,0)
red = (255,0,0)
orange = (255,200,0)
def text(msg,colour,box,x,y,w,h,size = 32):
    font = pygame.font.Font('freesansbold.ttf', size)
    text = font.render(msg, True, colour, box)
    textRect = text.get_rect()
    textRect.center = (x + (w // 2),y + (h // 2))
    screen.blit(text, textRect)

def button(x,y,w,h,msg,ACtxt,ACbox,NACtxt,NACbox,size = 30,action = None,border = None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,ACbox,(x,y,w,h))
        text(msg,ACtxt,ACbox,x,y,w,h,size)
        if click[0] == 1 and action != None:
            if action == "play":
                game_loop()
            elif action == "quit":
                pygame.quit()
                exit()
    else:
        pygame.draw.rect(screen,NACbox,(x,y,w,h))
        text(msg,NACtxt,NACbox,x,y,w,h,size = 50)
    if border == None:
        pygame.draw.rect(screen,(0,0,0),(x,y,10,h))
        pygame.draw.rect(screen,(0,0,0),(x,y,w,10))
        pygame.draw.rect(screen,(0,0,0),(x + w - 10,y,10,h))
        pygame.draw.rect(screen,(0,0,0),(x,y + h - 10,w,10))

# Starter Pic
starter_img = pygame.image.load("bucketstarter.png")

def starter(x,y):
    screen.blit(starter_img,(x,y))

while True:
    screen.fill((0,0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    button(25,400,375,200,"Start",blue,green,green,blue,size = 50,action = "play",border = "No")
    button(600,400,375,200,"Quit",red,orange,orange,red,size = 50,action = "quit",border = "No")
    starter(300,250)
    pygame.display.update()
'''
# program 3
'''
import pygame
import random
import math

pygame.init()
screen = pygame.display.set_mode((1000,600))

#Icon and Caption
pygame.display.set_caption("Plane Defender")
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)

def game_loop():
    # Player
    player_img = pygame.image.load("rocket_0.gif")
    playerw = 470
    playerh = 525

    def player(w,h):
        screen.blit(player_img,(w,h))

    # Bullet
    bullet_img = pygame.image.load("bullet.png")
    bulletw = -100
    bulleth = -100

    def bullet(w,h):
        screen.blit(bullet_img,(w,h))

    # Enemy 1
    enemy_img = pygame.image.load("enemy.png")
    enemyw = random.randint(50,900)
    enemyh = 50

    def enemy(w,h):
        screen.blit(enemy_img,(w,h))

    def collid(enemyh):
        lose_img = pygame.image.load("lose.png")
        losew = 250
        loseh = 100
        def lose():
            screen.blit(lose_img,(losew,loseh))
            button(150,400,300,150,green,blue,"Try Again",blue,green,size = 50,action = "play")
            button(500,400,300,150,orange,red,"Quit",red,orange,size = 50,action = "quit")
        if enemyh == 400:
            while True:
                screen.fill((255,255,255))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                lose()
                pygame.display.update()
   
    def repeat(enemyw,enemyh,bulletw,bulleth):
        distance1 = math.sqrt((math.pow((enemyw + 32) - (bulletw + 16),2)) + (math.pow((enemyh - 32) - (bulleth - 16),2)))
        if distance1 < 40:
            game_loop()
    while True:
        screen.fill((255,255,255))
        pygame.draw.rect(screen,(0,0,0),(0,450,1000,10))
        pygame.draw.rect(screen,(0,0,0),(0,0,1000,50))
        pygame.draw.rect(screen,(0,0,0),(0,570,1000,30))
        pygame.draw.rect(screen,(0,0,0),(0,0,50,600))
        pygame.draw.rect(screen,(0,0,0),(950,0,50,600))
        pygame.draw.rect(screen,(0,255,0),(50,50,900,400))
        pygame.draw.rect(screen,(0,0,255),(50,460,900,110))
        pygame.draw.rect(screen,(255,255,255),(20,20,960,10))
        pygame.draw.rect(screen,(255,255,255),(20,20,10,565))
        pygame.draw.rect(screen,(255,255,255),(970,20,10,565))
        pygame.draw.rect(screen,(255,255,255),(20,582,960,6))
        bullet(bulletw,bulleth)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    if playerw < 936:
                        playerw = playerw + 30
                    else:
                        pass
                if event.key == pygame.K_LEFT:
                    if playerw > 0:
                        playerw = playerw - 30
            if event.type == pygame.MOUSEBUTTONDOWN:
                if bulleth < 50:
                    bulletw = playerw + 16
                    bulleth = playerh - 32
        if bulleth < 600:
            bulleth = bulleth - 1
        else:
            pass
        enemy(enemyw,enemyh)
        integer = float(enemyh/100)
        if enemyw > 50 and enemyw < 900 and integer.is_integer() == False:
            enemyw = enemyw + 1
        elif enemyw > 50 and enemyh < 900 and integer.is_integer() == True:
            enemyw = enemyw - 1
        elif enemyw == 50 or enemyw == 900:
            enemyh = enemyh + 50
            if integer.is_integer() == False:
                enemyw = enemyw - 1
            if integer.is_integer() == True:
                enemyw = enemyw + 1
        collid(enemyh)
        repeat(enemyw,enemyh,bulletw,bulleth)
        player(playerw,playerh)    
        pygame.display.update()

def text(msg,colour,box,x,y,w,h,size = 32):
    font = pygame.font.Font("freesansbold.ttf",size)
    text = font.render(msg,True,colour,box)
    textRect = text.get_rect()
    textRect.center = (x + (w //2 ),y + (h // 2))
    screen.blit(text,textRect)

def button(x,y,w,h,ACbox,NACbox,msg,ACtxt,NACtxt,size = 32,action = None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,ACbox,(x,y,w,h))
        text(msg,ACtxt,ACbox,x,y,w,h,size)
        if click[0] == 1 and action != None:
            if action == "play":
                game_loop()
            if action == "quit":
                pygame.quit()
                exit()
    else: 
        pygame.draw.rect(screen,NACbox,(x,y,w,h))
        text(msg,NACtxt,NACbox,x,y,w,h,size)
blue = (0,0,255)
green = (0,255,0)
red = (255,0,0)
orange = (255,150,0)

# Starting pic
starting_img = pygame.image.load("startingrocket.png")

def startingpic(x,y):
    screen.blit(starting_img,(x,y))
    
while True:
    screen.fill((0,0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    startingpic(100,0)
    button(200,350,300,150,green,blue,"Start",blue,green,size = 50,action = "play")
    button(600,350,300,150,orange,red,"Quit",red,orange,size = 50,action = "quit")
    pygame.display.update()
'''
# Program 4
'''
import pygame
import time

pygame.init()
screen = pygame.display.set_mode((1000,600))

def text(msg,colour,box,x,y,w,h,size = 32):
    font = pygame.font.Font("freesansbold.ttf",size)
    text = font.render(msg,True,colour,box)
    textRect = text.get_rect()
    textRect.center = (x + (w // 2),y + (h // 2))
    screen.blit(text,textRect)

def button(ACbox,ACtxt,NACbox,NACtxt,x,y,w,h,msg,size = 32,action = None):
    mouse = pygame.mouse.get_pos()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,ACbox,(x,y,w,h))
        text(msg,ACtxt,ACbox,x,y,w,h,size)
        
    else:
        pygame.draw.rect(screen,NACbox,(x,y,w,h))
        text(msg,NACtxt,NACbox,x,y,w,h,size)

white = (255,255,255)
blue = (0,100,255)
green = (0,255,0)
black = (0,0,0)
red = (255,0,0)
orange = (255,100,0)

money = 0
price2 = 200
price1 = 100
slavepower = 0
slave = False
timedelay = pygame.USEREVENT + 1
worth = 1
amountslave = 0
amountclick = 0
slavepersec = 0
worthperclick = 1

while True:
    screen.fill(white) 
    mouse1 = pygame.mouse.get_pos()
    click1 = pygame.mouse.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if 700 > mouse1[0] > 300 and 300 > mouse1[1] > 100:
            if event.type == pygame.MOUSEBUTTONDOWN:
                money = money + worth
        if 400 > mouse1[0] > 100 and 500 > mouse1[1] > 400:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if money >= price1:
                    money = money - price1
                    slavepower = slavepower + 1
                    slave = True
                    price1 = price1 * 1.2
                    amountslave = amountslave + 1
                    slavepersec = slavepersec + 1
        if slave:
            pygame.time.set_timer(timedelay, 450)
        if event.type == timedelay:
            money = money + slavepower
        if 900 > mouse1[0] > 600 and 500 > mouse1[1] > 400:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if money >= price2:
                    money = money - price2
                    worth = worth * 1.5
                    price2 = price2 * 1.5
                    amountclick = amountclick + 1
                    worthperclick = worthperclick * 1.5
    button(green,white,blue,white,300,100,400,200,"Click to Earn Money")
    pygame.draw.rect(screen,black,(300,100,10,200))
    pygame.draw.rect(screen,black,(300,100,400,10))
    pygame.draw.rect(screen,black,(690,100,10,200))
    pygame.draw.rect(screen,black,(300,290,400,10))
    text(f"Slaves bought: {amountslave}",black,white,50,340,400,20,size = 15)
    text(f"Earns {slavepersec}/s",black,white,50,370,400,20,size = 15)
    button(orange,white,red,white,50,400,400,100,f"Buy Slave: {round(price1,1)}")
    pygame.draw.rect(screen,black,(50,400,10,100))
    pygame.draw.rect(screen,black,(50,400,400,10))
    pygame.draw.rect(screen,black,(440,400,10,100))
    pygame.draw.rect(screen,black,(50,490,400,10))
    text(f"X1.5 Click bought: {amountclick}",black,white,550,340,400,20,size = 15)
    text(f"Click worth: {round(worthperclick,2)}",black,white,550,370,400,20,size = 15)
    button(orange,white,red,white,550,400,400,100,f"X 1.5 Click: {round(price2,1)}")
    pygame.draw.rect(screen,black,(550,400,400,10))
    pygame.draw.rect(screen,black,(550,400,10,100))
    pygame.draw.rect(screen,black,(940,400,10,100))
    pygame.draw.rect(screen,black,(550,490,400,10))
    text(f"Money: {round(money,1)}",black,white,0,0,150,20,size = 15)
    if money >= 1000000:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
            pygame.display.update()
    pygame.display.update()
'''
# Program 5
'''
import pygame
import random

pygame.init()
# Screen size
tab_size = (1000,600)
screen = pygame.display.set_mode(tab_size)

# Caption
pygame.display.set_caption("Dealership")

# Colours
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
yellow = (255,255,0)
blue = (0,0,255)
green = (0,255,0)

def game_loop():
    worth1 = random.randint(25,150)
    worth2 = random.randint(10000,25000)
    worth3 = random.randint(250000,500000)
    money = 100
    time = 0
    redH = 0
    blueH = 0
    greenH = 0

    # win image
    win_img = pygame.image.load("youwin.png")
    def win(x,y):
        screen.blit(win_img,(x,y))
    
    while True:
        screen.fill(white)
        time = time + 1
        mouse1 = pygame.mouse.get_pos()
        if money >= 25000000:
            while True:
                screen.fill(black)
                win(200,150)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                    pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if 500 + 200 > mouse1[0] > 500 and 75 + 100 > mouse1[1] > 75:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if money >= worth1:
                        money = money - worth1
                        redH = redH + 1
            if 750 + 200 > mouse1[0] > 750 and 75 + 100 > mouse1[1] > 75:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if redH >= 1:
                        money = money + worth1
                        redH = redH - 1
            if 500 + 200 > mouse1[0] > 500 and 250 + 100 > mouse1[1] > 250:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if money >= worth2:
                        money = money - worth2
                        blueH = blueH + 1
            if 750 + 200 > mouse1[0] > 750 and 250 + 100 > mouse1[1] > 250:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if blueH >= 1:
                        money = money + worth2
                        blueH = blueH - 1
            if 500 + 200 > mouse1[0] > 500 and 425 + 100 > mouse1[1] > 425:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if money >= worth3:
                        money = money - worth3
                        greenH = greenH + 1
            if 750 + 200 > mouse1[0] > 750 and 425 + 100 > mouse1[1] > 425:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if greenH >= 1:
                        money = money + worth3
                        greenH = greenH - 1
        if time >= 225:
            worth1 = random.randint(25,150)
            worth2 = random.randint(10000,25000)
            worth3 = random.randint(250000,500000)
            time = 0
        button(f"Red Houses:{redH}",100,75,350,100,blue,blue,green,green,size = 32)
        button(f"Blue Houses:{blueH}",100,250,350,100,blue,blue,green,green,size = 32)
        button(f"Green Houses:{greenH}",100,425,350,100,blue,blue,green,green,size = 32)
        text(f"Money: ${money}",white,black,0,0,200,25,size = 16)
        text(f"Red Houses Worth: ${worth1}",white,black,130,50,300,25,size = 16)
        text(f"Blue Houses Worth: ${worth2}",white,black,130,225,300,25,size = 16)
        text(f"Green Houses Worth: ${worth3}",white,black,130,400,300,25,size = 16)
        button("Buy House",500,75,200,100,blue,green,green,blue,size = 32)
        button("Sell House",750,75,200,100,blue,green,green,blue,size = 32)
        button("Buy House",500,250,200,100,blue,green,green,blue,size = 32)
        button("Sell House",750,250,200,100,blue,green,green,blue,size = 32)
        button("Buy House",500,425,200,100,blue,green,green,blue,size = 32)
        button("Sell House",750,425,200,100,blue,green,green,blue,size = 32)
        pygame.display.update()

def text(msg,box,text,x,y,w,h,size):
    font = pygame.font.Font("freesansbold.ttf",size)
    text = font.render(msg,True,text,box)
    textRect = text.get_rect()
    textRect.center = (x + (w // 2),y + (h // 2))
    screen.blit(text,textRect)

def button(msg,x,y,w,h,Atxt,NAtxt,Abox,NAbox,size,action = None):
    global black
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,Abox,(x,y,w,h))
        text(msg,Abox,Atxt,x,y,w,h,size)
        if click[0] == 1 and action != None:
            if action == "play":
                game_loop()
            if action == "quit":
                pygame.quit()
                exit()
    else:
        pygame.draw.rect(screen,NAbox,(x,y,w,h))
        text(msg,NAbox,NAtxt,x,y,w,h,size)
    pygame.draw.rect(screen,black,(x,y,10,h))
    pygame.draw.rect(screen,black,(x,y,w,10))
    pygame.draw.rect(screen,black,(x + w - 10,y,10,h))
    pygame.draw.rect(screen,black,(x,y + h - 10,w,10))

while True:
    screen.fill(white)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    button("Quit",550,350,300,150,red,yellow,yellow,red,size = 50,action = "quit")
    button("Play",150,350,300,150,blue,green,green,blue,size = 50,action = "play")
    pygame.display.update()

'''
# Program
'''
import pygame
import random

pygame.init()
screen = pygame.display.set_mode((1000,600))

# Set Caption and Icon
pygame.display.set_caption("Pong")
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)

score1 = 0
score2 = 0

def gameloop():
    # Colours
    white = (255,255,255)
    black = (0,0,0)

    # Variables
    pongx = 400
    pongy = 400
    reverse = False
    direction2 = 1
    turn = 2
    hitwall = False
    hitwall2 = False
    global score1
    global score2

    # Ball
    ball_img = pygame.image.load("ball.png")
    ballw = 400
    ballh = 200

    def ball(ballw,ballh):
        screen.blit(ball_img,(ballw,ballh))

    while True:
        screen.fill(black)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if pongx <= 0:
                        pass
                    else:
                        pongx = pongx - 50
                if event.key == pygame.K_RIGHT:
                    if pongx >= 800:
                        pass
                    else:
                        pongx = pongx + 50
                if event.key == pygame.K_a:
                    if pongy <= 0:
                        pass
                    else:
                        pongy = pongy - 50
                if event.key == pygame.K_d:
                    if pongy  >= 800:
                        pass
                    else:
                        pongy = pongy + 50
        if reverse == False:
            if ballh <= 568:
                if pongx + 200 > ballw > pongx and 520 + 10 > ballh + 32 > 520:
                    direction = random.randint(1,2)
                    turn2 = random.randint(3,5)
                    hitwall = False
                    reverse = True
                else:
                    ballh = ballh + 1
                    if direction2 == 1:
                        if ballw >= 968:
                            hitwall2 = True
                        if hitwall2 == True:
                            ballw = ballw - (turn * 0.1)
                        elif hitwall2 == False:
                            ballw = ballw + (turn * 0.1)
                    if direction2 == 2:
                        if ballw <= 0:
                            hitwall2 = True
                        if hitwall2 == True:
                            ballw = ballw + (turn * 0.1)
                        elif hitwall2 == False:
                            ballw = ballw - (turn * 0.1)
        elif reverse == True:
            if ballh >= 0:
                if pongy + 200 > ballw > pongy and 80 + 10 > ballh > 80:
                    direction2 = random.randint(1,2)
                    turn = random.randint(3,5)
                    hitwall2 = False
                    reverse = False
                else:
                    ballh = ballh - 1
                    if direction == 1:
                        if ballw >= 968:
                            hitwall = True
                        if hitwall == True:
                            ballw = ballw - (turn2 * 0.1)
                        elif hitwall == False:
                            ballw = ballw + (turn2 * 0.1)
                    if direction == 2:
                        if ballw <= 0:
                            hitwall = True
                        if hitwall == True:
                            ballw = ballw + (turn2 * 0.1)
                        elif hitwall == False:
                            ballw = ballw - (turn2 * 0.1)
        if ballh <= 0:
            button("Play",150,350,300,150,(0,0,255),(0,255,0),(0,255,0),(0,0,255),32,white,action = "play")
            button("Quit",550,350,300,150,(255,0,0),(255,100,0),(255,100,0),(255,0,0),32,white,action = "quit")
        if ballh == 2:
            score1 = score1 + 1
        if ballh >= 568:
            button("Play",150,350,300,150,(0,0,255),(0,255,0),(0,255,0),(0,0,255),32,white,action = "play")
            button("Quit",550,350,300,150,(255,0,0),(255,100,0),(255,100,0),(255,0,0),32,white,action = "quit")
        if ballh == 566:
            score2 = score2 + 1
        ball(ballw,ballh)
        text(f"Score: {score2}",black,white,0,0,150,30,25)
        text(f"Score: {score1}",black,white,0,570,150,30,25)
        pygame.draw.rect(screen,white,(pongx,520,200,10))
        pygame.draw.rect(screen,white,(pongy,80,200,10))
        pygame.display.update()

def text(msg,box,text,x,y,w,h,size):
    font = pygame.font.Font("freesansbold.ttf",size)
    text = font.render(msg,True,text,box)
    textRect = text.get_rect()
    textRect.center = (x + (w // 2),y + (h // 2))
    screen.blit(text,textRect)

def button(msg,x,y,w,h,Atxt,NAtxt,Abox,NAbox,size,outline,action = None):
    global black
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,Abox,(x,y,w,h))
        text(msg,Abox,Atxt,x,y,w,h,size)
        if click[0] == 1 and action != None:
            if action == "play":
                gameloop()
            if action == "quit":
                pygame.quit()
                exit()
    else:
        pygame.draw.rect(screen,NAbox,(x,y,w,h))
        text(msg,NAbox,NAtxt,x,y,w,h,size)
    pygame.draw.rect(screen,outline,(x,y,10,h))
    pygame.draw.rect(screen,outline,(x,y,w,10))
    pygame.draw.rect(screen,outline,(x + w - 10,y,10,h))
    pygame.draw.rect(screen,outline,(x,y + h - 10,w,10))

black = (0,0,0)
white = (255,255,255)
while True:
    screen.fill(white)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    button("Play",150,350,300,150,(0,0,255),(0,255,0),(0,255,0),(0,0,255),32,black,action = "play")
    button("Quit",550,350,300,150,(255,0,0),(255,100,0),(255,100,0),(255,0,0),32,black,action = "quit")
    pygame.display.update()
'''
# Program 7
'''
import pygame

pygame.init()
width = 600
height = 400
size = (width,height)
screen = pygame.display.set_mode(size)

# Set Caption and Icon
pygame.display.set_caption("Tic Tac Toe")
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)

# Variables
black = (0,0,0)
white = (255,255,255)
blue = (0,0,235)
green = (0,255,0)
x_first = True
o_first = False
click1 = False
click2 = False
click3 = False
click4 = False
click5 = False
click6 = False
click7 = False
click8 = False
click9 = False
box1_x = False
box1_y = False
box2_x = False
box2_y = False
box3_x = False
box3_y = False
box4_x = False
box4_y = False
box5_x = False
box5_y = False
box6_x = False
box6_y = False
box7_x = False
box7_y = False
box8_x = False
box8_y = False
box9_x = False
box9_y = False
x_here1 = False
x_here2 = False
x_here3 = False
o_here1 = False
o_here2 = False
o_here3 = False
x_here4 = False
x_here5 = False
x_here6 = False
o_here4 = False
o_here5 = False
o_here6 = False
x_here7 = False
x_here8 = False
x_here9 = False
o_here7 = False
o_here8 = False
o_here9 = False
tick = 0
tick1 = False
first_try = "O"
o_point = 0
x_point = 0

def text(msg,colour,x,y,w,h,size):
    font = pygame.font.Font("freesansbold.ttf",size)
    text = font.render(msg,True,colour)
    textRect = text.get_rect()
    textRect.center = (x + (w //2),y + (h // 2))
    screen.blit(text,textRect)

def button(msg,x,y,w,h,AC,AT,NAC,NAT,size = 32,action = None):
    global click1,click2,click3,click4,click5,click6,click7,click8,click9,tick1,tick
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    tick = tick + 1
    if tick == 50:
        tick = 0
        tick1 = False
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen,AC,(x,y,w,h))
        text(msg,AT,x,y,w,h,size)
        if click[0] == 1 and action != None and tick1 == False:
            if action == "click1":
                click1 = True
            if action == "click2":
                click2 = True
            if action == "click3":
                click3 = True
            if action == "click4":
                click4 = True
            if action == "click5":
                click5 = True
            if action == "click6":
                click6 = True
            if action == "click7":
                click7 = True
            if action == "click8":
                click8 = True
            if action == "click9":
                click9 = True
            if action == "start":
                main_loop()
            if action == "quit":
                pygame.quit()
                exit()
            tick1 = True
    else:
        pygame.draw.rect(screen,NAC,(x,y,w,h))
        text(msg,NAT,x,y,w,h,size)
    pygame.draw.rect(screen,black,(x,y,w,5))
    pygame.draw.rect(screen,black,(x,y,5,h))
    pygame.draw.rect(screen,black,(x + w - 5,y,5,h))
    pygame.draw.rect(screen,black,(x,y + h - 5,w,5))

def reset():
    global click1,click2,click3,click4,click5,click6,click7,click8,click9
    global box1_x,box2_x,box3_x,box4_x,box5_x,box6_x,box7_x,box8_x,box9_x
    global box1_y,box2_y,box3_y,box4_y,box5_y,box6_y,box7_y,box8_y,box9_y
    global x_here1,x_here2,x_here3,x_here4,x_here5,x_here6,x_here7,x_here8,x_here9
    global o_here1,o_here2,o_here3,o_here4,o_here5,o_here6,o_here7,o_here8,o_here9
    click1 = False
    click2 = False
    click3 = False
    click4 = False
    click5 = False
    click6 = False
    click7 = False
    click8 = False
    click9 = False
    box1_x = False
    box1_y = False
    box2_x = False
    box2_y = False
    box3_x = False
    box3_y = False
    box4_x = False
    box4_y = False
    box5_x = False
    box5_y = False
    box6_x = False
    box6_y = False
    box7_x = False
    box7_y = False
    box8_x = False
    box8_y = False
    box9_x = False
    box9_y = False
    x_here1 = False
    x_here2 = False
    x_here3 = False
    o_here1 = False
    o_here2 = False
    o_here3 = False
    x_here4 = False
    x_here5 = False
    x_here6 = False
    o_here4 = False
    o_here5 = False
    o_here6 = False
    x_here7 = False
    x_here8 = False
    x_here9 = False
    o_here7 = False
    o_here8 = False
    o_here9 = False

def x_win():
    global o_point,x_point,first_try
    screen = pygame.display.set_mode((600,400))
    while True:
        global first_try
        screen.fill(white)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        reset()
        text(f"X Score: {x_point}",black,0,0,200,30,32)
        text(f"O Score: {o_point}",black,400,0,200,30,32)
        text("X WINS",black,0,0,600,200,150)
        button("Try Again",75,250,200,100,green,blue,blue,green,size = 32,action = "start")
        button("Quit",325,250,200,100,green,blue,blue,green,size = 32,action = "quit")
        text(first_try + " Goes First",white,100,300,150,50,16)
        pygame.display.update()

def o_win():
    global o_point,x_point,first_try
    screen = pygame.display.set_mode((600,400))
    while True:
        screen.fill(white)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        reset()
        text(f"X Score: {x_point}",black,0,0,200,30,32)
        text(f"O Score: {o_point}",black,400,0,200,30,32)
        text("O WINS",black,0,0,600,200,150)
        button("Try Again",75,250,200,100,green,blue,blue,green,size = 32,action = "start")
        button("Quit",325,250,200,100,green,blue,blue,green,size = 32,action = "quit")
        text(first_try + " Goes First",white,100,300,150,50,16)
        pygame.display.update()

def draw():
    global o_point,x_point,first_try
    screen = pygame.display.set_mode((600,400))
    while True:
        global first_try
        screen.fill(white)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        reset()
        text(f"X Score: {x_point}",black,0,0,200,30,32)
        text(f"O Score: {o_point}",black,400,0,200,30,32)
        text("Draw",black,0,0,600,200,150)
        button("Try Again",75,250,200,100,green,blue,blue,green,size = 32,action = "start")
        button("Quit",325,250,200,100,green,blue,blue,green,size = 32,action = "quit")
        text(first_try + " Goes First",white,100,300,150,50,16)
        pygame.display.update()

def main_loop():
    global click1,click2,click3,click4,click5,click6,click7,click8,click9
    global x_turn,o_turn,x_first,o_first,first_try,x_point,o_point
    global box1_x,box2_x,box3_x,box4_x,box5_x,box6_x,box7_x,box8_x,box9_x
    global box1_y,box2_y,box3_y,box4_y,box5_y,box6_y,box7_y,box8_y,box9_y
    global x_here1,x_here2,x_here3,x_here4,x_here5,x_here6,x_here7,x_here8,x_here9
    global o_here1,o_here2,o_here3,o_here4,o_here5,o_here6,o_here7,o_here8,o_here9
    if x_first == True:
        x_turn = True
        o_turn = False
        o_first = True
        x_first = False
        first_try = "O"
    elif o_first == True:
        o_turn = True
        x_turn = False
        x_first = True
        o_first = False
        first_try = "X"
    screen = pygame.display.set_mode((600,600))
    while True:
        screen.fill(white)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            
        button("",0,0,200,200,green,blue,blue,green,size = 18,action = "click1")
        button("",200,0,200,200,green,blue,blue,green,size = 18,action = "click2")
        button("",400,0,200,200,green,blue,blue,green,size = 18,action = "click3")
        button("",0,200,200,200,green,blue,blue,green,size = 18,action = "click4")
        button("",200,200,200,200,green,blue,blue,green,size = 18,action = "click5")
        button("",400,200,200,200,green,blue,blue,green,size = 18,action = "click6")
        button("",0,400,200,200,green,blue,blue,green,size = 18,action = "click7")
        button("",200,400,200,200,green,blue,blue,green,size = 18,action = "click8")
        button("",400,400,200,200,green,blue,blue,green,size = 18,action = "click9")
    
        if box1_x == True:
            click1 = False
            pygame.draw.line(screen,black,(25,25),(175,175),10)
            pygame.draw.line(screen,black,(25,175),(175,25),10)
        if box1_y == True:
            click1 = False
            pygame.draw.circle(screen,black,(100,100),80,10) 
        if click1 == True:
            if x_turn == True:
                box1_x = True
                o_turn = True
                x_turn = False
                click1 = False
                x_here1 = True
            elif o_turn == True:
                box1_y = True
                x_turn = True
                o_turn = False
                click1 = False
                o_here1 = True
    
        if box2_x == True:
            click2 = False
            pygame.draw.line(screen,black,(225,25),(375,175),10)
            pygame.draw.line(screen,black,(225,175),(375,25),10)
        if box2_y == True:
            click2 = False
            pygame.draw.circle(screen,black,(300,100),80,10)
        if click2 == True:
            if x_turn == True:
                box2_x = True
                o_turn = True
                x_turn = False
                click2 = False
                x_here2 = True
            elif o_turn == True:
                box2_y = True
                x_turn = True
                o_turn = False
                click2 = False
                o_here2 = True
            
        if box3_x == True:
            click3 = False
            pygame.draw.line(screen,black,(425,25),(575,175),10)
            pygame.draw.line(screen,black,(425,175),(575,25),10)
        if box3_y == True:
            click3 = False
            pygame.draw.circle(screen,black,(500,100),80,10)
        if click3 == True:
            if x_turn == True:
                box3_x = True
                o_turn = True
                x_turn = False
                click3 = False
                x_here3 = True
            elif o_turn == True:
                box3_y = True
                x_turn = True
                o_turn = False
                click3 = False
                o_here3 = True
            
        if box4_x == True:
            click4 = False
            pygame.draw.line(screen,black,(25,225),(175,375),10)
            pygame.draw.line(screen,black,(25,375),(175,225),10)
        if box4_y == True:
            click4 = False
            pygame.draw.circle(screen,black,(100,300),80,10) 
        if click4 == True:
            if x_turn == True:
                box4_x = True
                o_turn = True
                x_turn = False
                click4 = False
                x_here4 = True
            elif o_turn == True:
                box4_y = True
                x_turn = True
                o_turn = False
                click4 = False
                o_here4 = True
            
        if box5_x == True:
            click5 = False
            pygame.draw.line(screen,black,(225,225),(375,375),10)
            pygame.draw.line(screen,black,(225,375),(375,225),10)
        if box5_y == True:
            click5 = False
            pygame.draw.circle(screen,black,(300,300),80,10)
        if click5 == True:
            if x_turn == True:
                box5_x = True
                o_turn = True
                x_turn = False
                click5 = False
                x_here5 = True
            elif o_turn == True:
                box5_y = True
                x_turn = True
                o_turn = False
                click5 = False
                o_here5 = True
                
        if box6_x == True:
            click6 = False
            pygame.draw.line(screen,black,(425,225),(575,375),10)
            pygame.draw.line(screen,black,(425,375),(575,225),10)
        if box6_y == True:
            click6 = False
            pygame.draw.circle(screen,black,(500,300),80,10)
        if click6 == True:
            if x_turn == True:
                box6_x = True
                o_turn = True
                x_turn = False
                click6 = False
                x_here6 = True
            elif o_turn == True:
                box6_y = True
                x_turn = True
                o_turn = False
                click6 = False
                o_here6 = True
            
        if box7_x == True:
            click7 = False
            pygame.draw.line(screen,black,(25,425),(175,575),10)
            pygame.draw.line(screen,black,(25,575),(175,425),10)
        if box7_y == True:
            click7 = False
            pygame.draw.circle(screen,black,(100,500),80,10) 
        if click7 == True:
            if x_turn == True:
                box7_x = True
                o_turn = True
                x_turn = False
                click7 = False
                x_here7 = True
            elif o_turn == True:
                box7_y = True
                x_turn = True
                o_turn = False
                click7 = False
                o_here7 = True
            
        if box8_x == True:
            click8 = False
            pygame.draw.line(screen,black,(225,425),(375,575),10)
            pygame.draw.line(screen,black,(225,575),(375,425),10)
        if box8_y == True:
            click8 = False
            pygame.draw.circle(screen,black,(300,500),80,10)
        if click8 == True:
            if x_turn == True:
                box8_x = True
                o_turn = True
                x_turn = False
                click8 = False
                x_here8 = True
            elif o_turn == True:
                box8_y = True
                x_turn = True
                o_turn = False
                click8 = False
                o_here8 = True
            
        if box9_x == True:
            click9 = False
            pygame.draw.line(screen,black,(425,425),(575,575),10)
            pygame.draw.line(screen,black,(425,575),(575,425),10)
        if box9_y == True:
            click9 = False
            pygame.draw.circle(screen,black,(500,500),80,10)
        if click9 == True:
            if x_turn == True:
                box9_x = True
                o_turn = True
                x_turn = False
                click9 = False
                x_here9 = True
            elif o_turn == True:
                box9_y = True
                x_turn = True
                o_turn = False
                click9 = False
                o_here9 = True
        
        if x_turn == True:
            button("X turn",0,0,80,40,white,black,white,black,size = 20)
        elif o_turn == True:
            button("O turn",0,0,80,40,white,black,white,black,size = 16)
        
        pygame.display.update()
        if x_here1 == True and x_here2 == True and x_here3 == True:
            x_point = x_point + 1
            x_win()
        if o_here1 == True and o_here2 == True and o_here3 == True:
            o_point = o_point + 1
            o_win()
        if x_here4 == True and x_here5 == True and x_here6 == True:
            x_point = x_point + 1
            x_win()
        if o_here4 == True and o_here5 == True and o_here6 == True:
            o_point = o_point + 1
            o_win()
        if x_here7 == True and x_here8 == True and x_here9 == True:
            x_point = x_point + 1
            x_win()
        if o_here7 == True and o_here8 == True and o_here9 == True:
            o_point = o_point + 1
            o_win()
        if x_here1 == True and x_here4 == True and x_here7 == True:
            x_point = x_point + 1
            x_win()
        if o_here1 == True and o_here4 == True and o_here7 == True:
            o_point = o_point + 1
            o_win()
        if x_here2 == True and x_here5 == True and x_here8 == True:
            x_point = x_point + 1
            x_win()
        if o_here2 == True and o_here5 == True and o_here8 == True:
            o_point = o_point + 1
            o_win()
        if x_here3 == True and x_here6 == True and x_here9 == True:
            x_point = x_point + 1
            x_win()
        if o_here3 == True and o_here6 == True and o_here9 == True:
            o_point = o_point + 1
            o_win()
        if x_here1 == True and x_here5 == True and x_here9 == True:
            x_point = x_point + 1
            x_win()
        if o_here1 == True and o_here5 == True and o_here9 == True:
            o_point = o_point + 1
            o_win()
        if x_here3 == True and x_here5 == True and x_here7 == True:
            x_point = x_point + 1
            x_win()
        if o_here3 == True and o_here5 == True and o_here7 == True:
            o_point = o_point + 1
            o_win()
        if box1_x == True or box1_y == True:
            if box2_x == True or box2_y == True:
                if box3_x == True or box3_y == True:
                    if box4_x == True or box4_y == True:
                        if box5_x == True or box5_y == True:
                            if box6_x == True or box6_y == True:
                                if box7_x == True or box7_y == True:
                                    if box8_x == True or box8_y == True:
                                        if box9_x == True or box9_y == True:
                                            draw()

while True:
    screen.fill(white)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    text("Tic Tac Toe",black,0,0,600,200,100)
    button("Start",75,250,200,100,green,blue,blue,green,size = 32,action = "start")
    button("Quit",325,250,200,100,green,blue,blue,green,size = 32,action = "quit")
    pygame.display.update()
'''
# Program 8
'''
import pygame, random, math

pygame.init()
screen = pygame.display.set_mode((800,600))

# Caption
pygame.display.set_caption("")

# Variables
white = (255,255,255)
black = (0,0,0)
blue = (0,175,255)
green = (0,255,0)
brown = (139,69,19)
birdX = random.randint(200, 700)
wait = 0

# Player
player_img = pygame.image.load("playergun.png")
player_img = pygame.transform.scale(player_img, (150, 250))
def player(x,y):
    screen.blit(player_img,(x,y))

bird_img = pygame.image.load("bird.png")
bird_img = pygame.transform.scale(bird_img, (100, 100))
def bird(x,y):
    screen.blit(bird_img,(x,y))

bullet_img = pygame.image.load("bullet.png")
bulletx = 0
bullety = 800
def bullet(x,y):
    screen.blit(bullet_img,(x,y))
    
def hit():
    distance = math.sqrt(math.pow(bulletx - (birdX + 50),2)+math.pow(bullety-75,2))
    if distance >= 50:
        pass
    
while True:
    screen.fill(blue,(0,0,800,500))
    screen.fill(brown,(0,500,800,600))
    wait += 1
    for n in range(20):
        x = (n * 20) + (20 * n)
        y = 480
        screen.fill(green,(x,y,20,20))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    player(0,350)
    bird(birdX,25)
    bullet(bulletx,bullety)
    if wait == 500:
        birdX = random.randint(200,700)
        wait = 0
    pygame.display.update()
'''
